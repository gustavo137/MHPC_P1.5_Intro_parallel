# Lstopo Renderer (High-Resolution PNG Generator)

This package converts `lstopo --no-graphics` text output (like your `nodeArch.txt`) into
color-coded, full-detail, horizontal box layout PNGs and SVGs.

## Requirements
- Python 3.9+
- CairoSVG library

Install with:
    pip install cairosvg

## Usage
1. Place your `nodeArch.txt` in the same folder.
2. Run:
    python render_lstopo_pngs.py

This generates:
- `lstopo_full_box.png` (entire system, 12K px wide)
- `lstopo_NUMA0.png` ... `lstopo_NUMA7.png` (per NUMA node)
- Matching `.svg` versions for zoomable vector editing.

All images have white backgrounds, thin black borders, and titles.
