#!/bin/bash

module load hdf5
mpicc -O3 -o convert_IO.x convert_IO.c -I${HDF5_INCLUDE} -L${HDF5_LIB} -lhdf5

