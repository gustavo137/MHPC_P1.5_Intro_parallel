
<the full Python script content from the previous assistant message>
